document.getElementById("admissionForm").addEventListener("submit", function (e) {
    e.preventDefault();

    // Add form validation or data handling here
    alert("Your application has been submitted successfully!");
});
